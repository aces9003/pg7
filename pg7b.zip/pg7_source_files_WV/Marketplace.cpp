//
//  Marketplace.cpp
//  pg7
//
//  Created by Emily Johnson on 12/3/14.
//  Copyright (c) 2014 Emily Johnson. All rights reserved.
//

#include "Marketplace.h"
#include "Card.h"



/*
Marketplace::Marketplace(vector<Card> &deck){
    for(int i=0; i<5; i++){
        Card adder=deck.back();
        market.push_back(adder);
        deck.pop_back();
    }
}
*/