pg7 README
===

This project was a collaboration between Matthias Philippine, Alex Sharata, and Emily Johnson in EN 600.120 (02).

Compilation notes:

Compile with g++ -std=c++11 -pedantic -Wall -O *.cpp when running in a POSIX environment, or use the included Makefile.

Makefile commands:
...tbd
